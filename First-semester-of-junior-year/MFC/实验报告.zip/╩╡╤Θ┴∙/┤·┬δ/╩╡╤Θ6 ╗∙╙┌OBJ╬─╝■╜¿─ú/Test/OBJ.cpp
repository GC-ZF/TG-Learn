#include "pch.h"
#include "OBJ.h"

COBJ::COBJ(void)
{
}

COBJ::~COBJ(void)
{
}

void COBJ::ReadOBJFile(CString filePath)
{
    CStdioFile file;
    file.Open(filePath, CFile::modeRead);
    CString str;
    while (file.ReadString(str))
    {
        int c = 0;
        while (c >= 0)
        {
            CString s = str.Tokenize(" ", c);
            if (s == "v") // ���
            {
                CP3 v;
                CString string = str.Tokenize(" ", c);
                v.x = atof(string);
                string = str.Tokenize(" ", c);
                v.y = atof(string);
                string = str.Tokenize(" ", c);
                v.z = atof(string);
                vertex.push_back(v);
            }
            else if (s == "f")  // ���
            {
                CFacet f;
                while (c > 0) 
                {
                    CString string = str.Tokenize(" ", c);
                    int cc = 0;
                    int pIndex = atoi(string.Tokenize("/", cc));
                    if (pIndex > 0)
                    {
                        f.vIndex.push_back(pIndex - 1);
                    }
                }
                facet.push_back(f);
            }
        }
    }
    file.Close();
}

void COBJ::Draw(CDC* pDC)
{
    for (int f = 0; f < facet.size(); f++)
    {
        pDC->MoveTo(ROUND(vertex[facet[f].vIndex[0]].x), ROUND(vertex[facet[f].vIndex[0]].y));
        for (int v = 1; v < facet[f].vIndex.size(); v++)
        {
            pDC->LineTo(ROUND(vertex[facet[f].vIndex[v]].x), ROUND(vertex[facet[f].vIndex[v]].y));
        }
        pDC->LineTo(ROUND(vertex[facet[f].vIndex[0]].x), ROUND(vertex[facet[f].vIndex[0]].y));
    }
}
