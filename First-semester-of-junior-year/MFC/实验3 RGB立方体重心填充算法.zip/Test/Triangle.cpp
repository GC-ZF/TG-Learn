#include "pch.h"
#include "Triangle.h"
#define ROUND(d) int(d + 0.5)

CTriangle::CTriangle(void)
{

}

CTriangle::~CTriangle(void)
{

}

void CTriangle::SetPoint(CP2 P0, CP2 P1, CP2 P2)//�������η�Ϊ����������
{
	point[0].x = ROUND(P0.x);
	point[0].y = ROUND(P0.y);
	point[0].c = P0.c;
	point[1].x = ROUND(P1.x);
	point[1].y = ROUND(P1.y);
	point[1].c = P1.c;
	point[2].x = ROUND(P2.x);
	point[2].y = ROUND(P2.y);
	point[2].c = P2.c;
}

void CTriangle::Fill(CDC* pDC)
{
	/*SortVertex();*///point0��Ϊy������С�ĵ�,point1��Ϊy�������ĵ�,point2���y����λ�ڶ���֮�䡣���yֵ��ͬ��ȡx��С�ĵ�

	int xMin = min(min(point[0].x, point[1].x), point[2].x);
	int yMin = min(min(point[0].y, point[1].y), point[2].y);
	int xMax = max(max(point[0].x, point[1].x), point[2].x);
	int yMax = max(max(point[0].y, point[1].y), point[2].y);
	for (int y = yMin; y < yMax; y++) {
		for (int x = xMin; x < xMax; x++) {
			double Area = point[0].x*point[1].y + point[1].x*point[2].y + point[2].x*point[0].y - point[2].x*point[1].y - point[1].x*point[0].y - point[0].x*point[2].y;
			double subArea0 = x * point[1].y + point[1].x*point[2].y + point[2].x*y - point[2].x*point[1].y - point[1].x*y - x * point[2].y;
			double subArea1 = point[0].x*y + x * point[2].y + point[2].x*point[0].y - point[2].x*y - x * point[0].y - point[0].x*point[2].y;
			double alpha = subArea0 / Area, beta = subArea1 / Area;//��������
			if (alpha >= 0 && beta >= 0 && alpha + beta <= 1) {
				CRGB crColor = alpha * point[0].c + beta * point[1].c + (1 - alpha - beta)*point[2].c;//�����������������������һ����ɫ
				pDC->SetPixel(x, y, RGB(crColor.red * 255, crColor.green * 255, crColor.blue * 255));
			}
		}
	}

	////���������θ��ǵ�ɨ��������
	//int nTotalScanLine = point[1].y - point[0].y + 1;
	////����span��������յ�����
	//SpanLeft = new CPoint2[nTotalScanLine];
	//SpanRight = new CPoint2[nTotalScanLine];
	////�ж���������P0P1�ߵ�λ�ù�ϵ��0-1-2Ϊ����ϵ
	//int nDeltz = (point[1].x - point[0].x) * (point[2].y - point[1].y) - (point[1].y - point[0].y) * (point[2].x - point[1].x);//�淨������z����
	//if (nDeltz > 0)//������λ��P0P1�ߵ����
	//{
	//	nIndex = 0;
	//	EdgeFlag(point[0], point[2], TRUE);
	//	EdgeFlag(point[2], point[1], TRUE);
	//	nIndex = 0;
	//	EdgeFlag(point[0], point[1], FALSE);
	//}
	//else//������λ��P0P1�ߵ��Ҳ�
	//{
	//	nIndex = 0;
	//	EdgeFlag(point[0], point[1], TRUE);
	//	nIndex = 0;
	//	EdgeFlag(point[0], point[2], FALSE);
	//	EdgeFlag(point[2], point[1], FALSE);
	//}
	//for (int y = point[0].y; y < point[1].y; y++)//�±��Ͽ�
	//{
	//	int n = y - point[0].y;
	//	for (int x = SpanLeft[n].x; x < SpanRight[n].x; x++)//����ҿ�
	//	{
	//		CRGB clr = LinearInterp(x, SpanLeft[n].x, SpanRight[n].x, SpanLeft[n].c, SpanRight[n].c);
	//		pDC->SetPixelV(x, y, RGB(clr.red * 255, clr.green * 255, clr.blue * 255));
	//	}
	//}
	//if (SpanLeft)
	//{
	//	delete[]SpanLeft;
	//	SpanLeft = NULL;
	//}
	//if (SpanRight)
	//{
	//	delete[]SpanRight;
	//	SpanRight = NULL;
	//}
}

//void CTriangle::EdgeFlag(CPoint2 PStart, CPoint2 PEnd, BOOL bFeature)
//{
//	int dx = PEnd.x - PStart.x;
//	int dy = PEnd.y - PStart.y;
//	double m = double(dx) / dy;
//	double x = PStart.x;
//	for(int y = PStart.y; y < PEnd.y; y++)
//	{
//		CRGB crColor = LinearInterp(y, PStart.y, PEnd.y, PStart.c, PEnd.c);
//		if(bFeature)
//			SpanLeft[nIndex++] = CPoint2(ROUND(x), y, crColor);
//		else
//			SpanRight[nIndex++] = CPoint2(ROUND(x), y, crColor);
//		x += m;
//	}
//}

void CTriangle::SortVertex(void)
{
	CPoint2 pt[3];
	pt[0] = point[0];
	pt[1] = point[1];
	pt[2] = point[2];
	for (int i = 0; i < 2; i++)
	{
		for (int j = i + 1; j < 3; j++)
		{
			int k = i;
			if (pt[k].y >= pt[j].y)
				k = j;
			if (k == j)
			{
				CPoint2 ptTemp = pt[i];
				pt[i] = pt[k];
				pt[k] = ptTemp;
			}
		}
	}
	point[0] = pt[0];
	point[1] = pt[2];
	point[2] = pt[1];
}

//CRGB CTriangle::LinearInterp(double t, double tStart, double tEnd, CRGB cStart, CRGB cEnd)//��ɫ���Բ�ֵ
//{
//	CRGB color;
//	color = (tEnd - t) / (tEnd - tStart) * cStart + (t - tStart) / (tEnd - tStart) * cEnd;
//	return color;
//}