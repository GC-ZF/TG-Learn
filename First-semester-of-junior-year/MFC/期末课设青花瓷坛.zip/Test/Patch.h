#pragma once
class CPatch
{
public:
	CPatch(void);
	virtual ~CPatch(void);
public:	
	int pIndex[4][4];
};

