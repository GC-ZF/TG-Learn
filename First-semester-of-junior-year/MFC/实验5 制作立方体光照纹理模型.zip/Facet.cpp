#include "pch.h"
#include "Facet.h"

CFacet::CFacet(void)
{
}


CFacet::~CFacet(void)
{
}

