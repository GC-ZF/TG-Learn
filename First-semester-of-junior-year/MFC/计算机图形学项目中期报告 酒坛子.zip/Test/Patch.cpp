#include "pch.h"
#include "Patch.h"

CPatch::CPatch(void)
{
}


CPatch::~CPatch(void)
{
}
