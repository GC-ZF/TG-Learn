#pragma once
#include "P2.h"

class CP3:public CP2
{
public:
	CP3(void);
	virtual ~CP3(void);
	CP3(double x, double y, double z);
public:
	double z;
};