#pragma once
class CP2
{
public:
	CP2(void);
	virtual ~CP2(void);
	CP2(double x, double y);
public:
	double x, y, w;
};

