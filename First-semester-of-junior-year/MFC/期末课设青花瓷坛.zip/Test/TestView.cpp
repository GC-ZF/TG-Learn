﻿
// TestView.cpp: CTestView 类的实现
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS 可以在实现预览、缩略图和搜索筛选器句柄的
// ATL 项目中进行定义，并允许与该项目共享文档代码。
#ifndef SHARED_HANDLERS
#include "Test.h"
#endif

#include "TestDoc.h"
#include "TestView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CTestView

IMPLEMENT_DYNCREATE(CTestView, CView)

BEGIN_MESSAGE_MAP(CTestView, CView)
	// 标准打印命令
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CView::OnFilePrintPreview)
	ON_COMMAND(ID_GRAPH_ANIMATION, &CTestView::OnGraphAnimation)
	ON_UPDATE_COMMAND_UI(ID_GRAPH_ANIMATION, &CTestView::OnUpdateGraphAnimation)
	ON_WM_TIMER()
	ON_WM_KEYDOWN()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
END_MESSAGE_MAP()

// CTestView 构造/析构

CTestView::CTestView() noexcept
{
	// TODO: 在此处添加构造代码
	bPlay = FALSE;
	double Q = 40;
	double m = 0.5523;
	CP2 P2[4];//二维控制点
	//4个二维点模拟坛身
	P2[0] = CP2(2.09, -3.39);
	P2[1] = CP2(3.65, -1.91);
	P2[2] = CP2(5.65, 4.56);
	P2[3] = CP2(1.5, 4.57);

	//绘制坛身1
	CP3 PointBody1[4];//坛身的三维控制点
	PointBody1[0] = CP3(P2[0].x, P2[0].y, 0.0);
	PointBody1[1] = CP3(P2[1].x, P2[1].y, 0.0);
	PointBody1[2] = CP3(P2[2].x, P2[2].y, 0.0);
	PointBody1[3] = CP3(P2[3].x, P2[3].y, 0.0);

	revoBody1.ReadCubicBezierControlPoint(PointBody1);
	tranBody1.SetMatrix(revoBody1.GetVertexArrayName(), 48);
	tranBody1.Scale(Q, Q, Q);//缩小

	//绘制坛身2
	CP3 PointBody2[4];//坛身的三维控制点
	PointBody2[0] = CP3(P2[3].x, P2[3].y, 0.0);
	PointBody2[1] = CP3(P2[3].x, P2[3].y + 0.6, 0.0);
	PointBody2[2] = CP3(P2[3].x, P2[3].y + 0.6, 0.0);
	PointBody2[3] = CP3(P2[3].x, P2[3].y + 0.6, 0.0);

	revoBody2.ReadCubicBezierControlPoint(PointBody2);
	tranBody2.SetMatrix(revoBody2.GetVertexArrayName(), 48);
	tranBody2.Scale(Q, Q, Q);


	//绘制坛底
	CP3 PointBottom[4];//坛底的三维控制点
	PointBottom[0] = CP3(P2[0].x, P2[0].y, 0.0);
	PointBottom[1] = CP3(P2[0].x - 1.5, P2[0].y, 0.0);
	PointBottom[2] = CP3(P2[0].x - 1.2, P2[0].y + 1, 0.0);
	PointBottom[3] = CP3(0.0, P2[0].y + 1, 0.0);

	revoBottom.ReadCubicBezierControlPoint(PointBottom);
	tranBottom.SetMatrix(revoBottom.GetVertexArrayName(), 48);
	tranBottom.Scale(Q, Q, Q);//缩小

	////4个二维点模拟坛盖
	CP2 P3[4];
	P3[0] = CP2(1.4, 4.57);
	P3[1] = CP2(1.4, 5.17);
	P3[2] = CP2(3.5, 5);
	P3[3] = CP2(0, 5.3);
	CP3 PointLid[4];//坛盖的三维控制点
	PointLid[0] = CP3(P3[0].x, P3[0].y, 0.0);
	PointLid[1] = CP3(P3[1].x, P3[1].y, 0.0);
	PointLid[2] = CP3(P3[2].x, P3[2].y, 0.0);
	PointLid[3] = CP3(P3[3].x, P3[3].y, 0.0);

	revoLid.ReadCubicBezierControlPoint(PointLid);
	tranLid.SetMatrix(revoLid.GetVertexArrayName(), 48);
	tranLid.Scale(Q, Q, Q);//缩小


	InitializeLightingScene();
	revoBody1.patch.SetScene(pLight, pMaterial);//设置场景
	revoBody2.patch.SetScene(pLight, pMaterial);//设置场景
	revoBottom.patch.SetScene(pLight, pMaterial);//设置场景
	revoLid.patch.SetScene(pLight, pMaterial);//设置场景
	/*-> 设置纹理*/
	//4是花纹，5是主体
	texture1.PrepareBitmap(IDB_BITMAP4);//准备位图
	texture2.PrepareBitmap(IDB_BITMAP5);//准备位图


	revoBody1.patch.SetTexture(&texture2);
	revoBody2.patch.SetTexture(&texture2);
	revoBottom.patch.SetTexture(&texture1);
	revoLid.patch.SetTexture(&texture1);
}

CTestView::~CTestView()
{
	if (pLight != NULL)
	{
		delete pLight;
		pLight = NULL;
	}
	if (pMaterial != NULL)
	{
		delete pMaterial;
		pMaterial = NULL;
	}
	//texture1.DeleteObject();
	//texture2.DeleteObject();
}

void CTestView::InitializeLightingScene(void)//初始化光照环境
{
	//设置光源属性
	nLightSourceNumber = 1;//光源个数
	pLight = new CLighting(nLightSourceNumber);//一维光源动态数组
	pLight->LightSource[0].SetPosition(1000, 700, 1000);//设置光源位置坐标
	for (int i = 0; i < nLightSourceNumber; i++)
	{
		pLight->LightSource[i].L_Diffuse = CRGB(1.0, 1.0, 1.0);//光源的漫反射颜色
		pLight->LightSource[i].L_Specular = CRGB(1.0, 1.0, 1.0);//光源镜面高光颜色
		pLight->LightSource[i].L_C0 = 1.0;//常数衰减因子
		pLight->LightSource[i].L_C1 = 0.0000001;//线性衰减因子
		pLight->LightSource[i].L_C2 = 0.00000001;//二次衰减因子
		pLight->LightSource[i].L_OnOff = TRUE;//光源开启
	}
	//设置材质属性
	pMaterial = new CMaterial;
	pMaterial->SetAmbient(CRGB(0.847, 0.10, 0.075));//环境反射率
	pMaterial->SetDiffuse(CRGB(0.852, 0.006, 0.026));//漫反射率
	pMaterial->SetSpecular(CRGB(1.0, 1.0, 1.0));//镜面反射率
	pMaterial->SetEmission(CRGB(0.0, 0.0, 0.0));//自身辐射的颜色
	pMaterial->SetExponent(50);//高光指数
}

BOOL CTestView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: 在此处通过修改
	//  CREATESTRUCT cs 来修改窗口类或样式

	return CView::PreCreateWindow(cs);
}

// CTestView 绘图

void CTestView::OnDraw(CDC* pDC)
{
	CTestDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	// TODO: 在此处为本机数据添加绘制代码
	DoubleBuffer(pDC);
}

void CTestView::DoubleBuffer(CDC* pDC)//双缓冲
{
	CRect rect;//定义客户区矩形
	GetClientRect(&rect);//获得客户区的大小
	pDC->SetMapMode(MM_ANISOTROPIC);//pDC自定义坐标系
	pDC->SetWindowExt(rect.Width(), rect.Height());//设置窗口范围
	pDC->SetViewportExt(rect.Width(), -rect.Height());//设置视区范围,x轴水平向右，y轴垂直向上
	pDC->SetViewportOrg(rect.Width() / 2, rect.Height() / 2);//客户区中心为原点
	CDC memDC;//内存DC
	memDC.CreateCompatibleDC(pDC);//创建一个与显示pDC兼容的内存memDC

	CBitmap NewBitmap, *pOldBitmap;//内存中承载的临时位图 
	NewBitmap.CreateCompatibleBitmap(pDC, rect.Width(), rect.Height());//创建兼容位图 
	pOldBitmap = memDC.SelectObject(&NewBitmap);//将兼容位图选入memDC 
	memDC.FillSolidRect(rect, pDC->GetBkColor());//按原来背景填充客户区，否则是黑色
	memDC.SetMapMode(MM_ANISOTROPIC);//memDC自定义坐标系
	memDC.SetWindowExt(rect.Width(), rect.Height());
	memDC.SetViewportExt(rect.Width(), -rect.Height());
	memDC.SetViewportOrg(rect.Width() / 2, rect.Height() / 2);
	rect.OffsetRect(-rect.Width() / 2, -rect.Height() / 2);
	DrawObject(&memDC);//向memDC绘制图形
	pDC->BitBlt(rect.left, rect.top, rect.Width(), rect.Height(), &memDC, -rect.Width() / 2, -rect.Height() / 2, SRCCOPY);//将内存memDC中的位图拷贝到显示pDC中
	memDC.SelectObject(pOldBitmap);//恢复位图
	NewBitmap.DeleteObject();//删除位图
}

void CTestView::DrawObject(CDC* pDC)//绘制图形
{
	CZBuffer* pZBuffer = new CZBuffer;
	pZBuffer->InitialDepthBuffer(1000, 1000, 2000);//初始化深度缓冲器
	revoBody1.DrawRevolutionSurface(pDC, pZBuffer);
	revoBody2.DrawRevolutionSurface(pDC, pZBuffer);
	revoBottom.DrawRevolutionSurface(pDC, pZBuffer);
	revoLid.DrawRevolutionSurface(pDC, pZBuffer);
	delete pZBuffer;
}

// CTestView 打印

BOOL CTestView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// 默认准备
	return DoPreparePrinting(pInfo);
}

void CTestView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 添加额外的打印前进行的初始化过程
}

void CTestView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 添加打印后进行的清理过程
}


// CTestView 诊断

#ifdef _DEBUG
void CTestView::AssertValid() const
{
	CView::AssertValid();
}

void CTestView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CTestDoc* CTestView::GetDocument() const // 非调试版本是内联的
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTestDoc)));
	return (CTestDoc*)m_pDocument;
}
#endif //_DEBUG


// CTestView 消息处理程序


void CTestView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	// TODO: 在此添加消息处理程序代码和/或调用默认值
	switch (nChar)
	{
	case VK_UP:
		Alpha = -5;
		tranBody1.RotateX(Alpha);
		tranBody2.RotateX(Alpha);
		tranBottom.RotateX(Alpha);
		tranLid.RotateX(Alpha);
		break;
	case VK_DOWN:
		Alpha = +5;
		tranBody1.RotateX(Alpha);
		tranBody2.RotateX(Alpha);
		tranBottom.RotateX(Alpha);
		tranLid.RotateX(Alpha);
		break;
	case VK_LEFT:
		Beta = -5;
		tranBody1.RotateY(Beta);
		tranBody2.RotateY(Beta);
		tranBottom.RotateY(Beta);
		tranLid.RotateY(Beta);
		break;
	case VK_RIGHT:
		Beta = +5;
		tranBody1.RotateY(Beta);
		tranBody2.RotateY(Beta);
		tranBottom.RotateY(Beta);
		tranLid.RotateY(Beta);
		break;
	default:
		break;
	}
	Invalidate(FALSE);
	CView::OnKeyDown(nChar, nRepCnt, nFlags);
}

void CTestView::OnGraphAnimation()
{
	// TODO: 在此添加命令处理程序代码
	bPlay = !bPlay;
	if (bPlay)//设置定时器
		SetTimer(1, 150, NULL);
	else
		KillTimer(1);
}

void CTestView::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: 在此添加消息处理程序代码和/或调用默认值
	Alpha = 5;	Beta = 5;
	tranBody1.RotateX(Alpha);
	tranBody2.RotateX(Alpha);
	tranBottom.RotateX(Alpha);
	tranLid.RotateX(Alpha);
	tranBody1.RotateY(Beta);
	tranBody2.RotateY(Beta);
	tranBottom.RotateY(Beta);
	tranLid.RotateY(Beta);
	Invalidate(FALSE);
	CView::OnTimer(nIDEvent);
}

void CTestView::OnUpdateGraphAnimation(CCmdUI *pCmdUI)
{
	// TODO: 在此添加命令更新用户界面处理程序代码
	if (bPlay)
		pCmdUI->SetCheck(TRUE);
	else
		pCmdUI->SetCheck(FALSE);
}


void CTestView::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: 在此添加消息处理程序代码和/或调用默认值
	p0 = point;
	CView::OnLButtonDown(nFlags, point);
}


void CTestView::OnLButtonUp(UINT nFlags, CPoint point)
{
	// TODO: 在此添加消息处理程序代码和/或调用默认值

	p1 = point;
	CDC*pDC = GetDC();

	CPen NewPen, *pOldPen;//画笔
	NewPen.CreatePen(PS_SOLID, 3, RGB(0, 0, 128));//画笔属性
	pOldPen = pDC->SelectObject(&NewPen);//选入设备描述表
	pDC->MoveTo(p0);
	pDC->LineTo(p1);

	Alpha = p1.x - p0.x;
	Beta = p1.y - p0.y;
	tranBody1.RotateY(Alpha);
	tranBody1.RotateX(Beta);

	tranBody2.RotateY(Alpha);
	tranBody2.RotateX(Beta);

	tranBottom.RotateY(Alpha);
	tranBottom.RotateX(Beta);

	tranLid.RotateY(Alpha);
	tranLid.RotateX(Beta);

	ReleaseDC(pDC);//删除
	Invalidate(FALSE);
	
	CView::OnLButtonUp(nFlags, point);
}
