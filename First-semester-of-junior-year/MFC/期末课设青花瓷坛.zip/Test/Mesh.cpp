#include "pch.h"
#include "Mesh.h"

CMesh::CMesh(void)
{
}

CMesh:: ~CMesh(void)
{
}
