#include "pch.h"
#include "Cube.h"

#define ROUND(d) int(d + 0.5)
#define Gold 0.618
CCube::CCube(void)
{

}

CCube::~CCube(void)
{

}

CP3* CCube::GetVertexArrayName(void)
{
	return	P;
}

void CCube::ReadPoint(void)//���
{
	//�������ά����(x,y,z)
	//P[0].x = -1, P[0].y = -1, P[0].z = 1;
	//P[1].x = 1, P[1].y = -1, P[1].z = 1;
	//P[2].x = 1, P[2].y = 1, P[2].z = 1;
	//P[3].x = -1, P[3].y = 1, P[3].z = 1;
	//P[4].x = -1, P[4].y = -1, P[4].z = -1;
	//P[5].x = 1, P[5].y = -1, P[5].z = -1;
	//P[6].x = 1, P[6].y = 1, P[6].z = -1;
	//P[7].x = -1, P[7].y = 1, P[7].z = -1;

	////xoy����ε�
	//P[8].x = -Gold, P[8].y = -1 / Gold, P[8].z = 0;
	//P[9].x = Gold, P[9].y = -1 / Gold, P[9].z = 0;
	//P[10].x = Gold, P[10].y = 1 / Gold, P[10].z = 0;
	//P[11].x = -Gold, P[11].y = 1 / Gold, P[11].z = 0;

	////xoz����ε�
	//P[12].x = -1 / Gold, P[12].y = 0, P[12].z = Gold;
	//P[13].x = 1 / Gold, P[13].y = 0, P[13].z = Gold;
	//P[14].x = 1 / Gold, P[14].y = 0, P[14].z = -Gold;
	//P[15].x = -1 / Gold, P[15].y = 0, P[15].z = -Gold;

	////yoz����ε�
	//P[16].x = 0, P[16].y = -Gold, P[16].z = 1 / Gold;
	//P[17].x = 0, P[17].y = -Gold, P[17].z = -1 / Gold;
	//P[18].x = 0, P[18].y = Gold, P[18].z = -1 / Gold;
	//P[19].x = 0, P[19].y = Gold, P[19].z = 1 / Gold;

	double a = 2;//������
	double b = 0.618033/*sqrt(pow((a*sin(72) / (cos(36) * 2)), 2) - pow((a / 2), 2))*/;
	double c =1.23 /*a / (2 * sin(54))*/;//��
	double d = 3.236066/*0.61803*//*a + 2 * b*/;//��

	P[0].x = -1, P[0].y = -1, P[0].z = 1;
	P[1].x = 1, P[1].y = -1, P[1].z = 1;
	P[2].x = 1, P[2].y = 1, P[2].z = 1;
	P[3].x = -1, P[3].y = 1, P[3].z = 1;
	P[4].x = -1, P[4].y = -1, P[4].z = -1;
	P[5].x = 1, P[5].y = -1, P[5].z = -1;
	P[6].x = 1, P[6].y = 1, P[6].z = -1;
	P[7].x = -1, P[7].y = 1, P[7].z = -1;
	P[8].x = -c / 2, P[8].y = -d / 2, P[8].z = 0;
	P[9].x = c / 2, P[9].y = -d / 2, P[9].z = 0;
	P[10].x = c / 2, P[10].y = d / 2, P[10].z = 0;
	P[11].x = -c / 2, P[11].y = d / 2, P[11].z = 0;
	P[12].x = -d / 2, P[12].y = 0, P[12].z = c / 2;
	P[13].x = d / 2, P[13].y = 0, P[13].z = c / 2;
	P[14].x = d / 2, P[14].y = 0, P[14].z = -c / 2;
	P[15].x = -d / 2, P[15].y = 0, P[15].z = -c / 2;
	P[16].x = 0, P[16].y = -c / 2, P[16].z = d / 2;
	P[17].x = 0, P[17].y = -c / 2, P[17].z = -d / 2;
	P[18].x = 0, P[18].y = c / 2, P[18].z = -d / 2;
	P[19].x = 0, P[19].y = c / 2, P[19].z = d / 2;
}


void CCube::ReadFacet(void)//���
{
	//��Ķ������
	//ǰ��6����
	//F[0].Index[0] = 0;	F[0].Index[1] = 16;	F[0].Index[2] = 19;	F[0].Index[3] = 3;	F[0].Index[4] = 12;
	//F[1].Index[0] = 0;	F[1].Index[1] = 8;	F[1].Index[2] = 9;	F[1].Index[3] = 1;	F[1].Index[4] = 16;
	//F[2].Index[0] = 1;	F[2].Index[1] = 9;  F[2].Index[2] = 5;	F[2].Index[3] = 14; F[2].Index[4] = 13;
	//F[3].Index[0] = 1;	F[3].Index[1] = 13;	F[3].Index[2] = 2;	F[3].Index[3] = 19;	F[3].Index[4] = 16;
	//F[4].Index[0] = 2;	F[4].Index[1] = 10;	F[4].Index[2] = 11;	F[4].Index[3] = 3;	F[4].Index[4] = 19;
	//F[5].Index[0] = 2;	F[5].Index[1] = 13;	F[5].Index[2] = 14;	F[5].Index[3] = 6;	F[5].Index[4] = 10;

	////��6����
	//F[6].Index[0] = 4;	F[6].Index[1] = 17; F[6].Index[2] = 5;  F[6].Index[3] = 9;  F[6].Index[4] = 8;
	//F[7].Index[0] = 0;	F[7].Index[1] = 12; F[7].Index[2] = 15; F[7].Index[3] = 4;  F[7].Index[4] = 8;
	//F[8].Index[0] = 4;	F[8].Index[1] = 15; F[8].Index[2] = 7;  F[8].Index[3] = 18; F[8].Index[4] = 17;
	//F[9].Index[0] = 3;	F[9].Index[1] = 11; F[9].Index[2] = 7;  F[9].Index[3] = 15; F[9].Index[4] = 12;
	//F[10].Index[0] = 6; F[10].Index[1] = 18; F[10].Index[2] = 7;  F[10].Index[3] = 11; F[10].Index[4] = 10;
	//F[11].Index[0] = 5; F[11].Index[1] = 17; F[11].Index[2] = 18; F[11].Index[3] = 6;  F[11].Index[4] = 14;

	F[0].Index[0] = 0; F[0].Index[1] = 16; F[0].Index[2] = 19; F[0].Index[3] = 3; F[0].Index[4] = 12;
	F[1].Index[0] = 0; F[1].Index[1] = 8; F[1].Index[2] = 9; F[1].Index[3] = 1; F[1].Index[4] = 16;
	F[2].Index[0] = 0; F[2].Index[1] = 12; F[2].Index[2] = 15; F[2].Index[3] = 4; F[2].Index[4] = 8;
	F[3].Index[0] = 1; F[3].Index[1] = 13; F[3].Index[2] = 2; F[3].Index[3] = 19; F[3].Index[4] = 16;
	F[4].Index[0] = 1; F[4].Index[1] = 9; F[4].Index[2] = 5; F[4].Index[3] = 14; F[4].Index[4] = 13;
	F[5].Index[0] = 2; F[5].Index[1] = 13; F[5].Index[2] = 14; F[5].Index[3] = 6; F[5].Index[4] = 10;
	F[6].Index[0] = 2; F[6].Index[1] = 10; F[6].Index[2] = 11; F[6].Index[3] = 3; F[6].Index[4] = 19;
	F[7].Index[0] = 3; F[7].Index[1] = 11; F[7].Index[2] = 7; F[7].Index[3] = 15; F[7].Index[4] = 12;
	F[8].Index[0] = 4; F[8].Index[1] = 17; F[8].Index[2] = 5; F[8].Index[3] = 9; F[8].Index[4] = 8;
	F[9].Index[0] = 4; F[9].Index[1] = 15; F[9].Index[2] = 7; F[9].Index[3] = 18; F[9].Index[4] = 17;
	F[10].Index[0] = 5; F[10].Index[1] = 17; F[10].Index[2] = 18; F[10].Index[3] = 6; F[10].Index[4] = 14;
	F[11].Index[0] = 6; F[11].Index[1] = 18; F[11].Index[2] = 7; F[11].Index[3] = 11; F[11].Index[4] = 10;
}

void CCube::Draw(CDC* pDC)//����ͶӰ
{
	CP2 ScreenPoint, temp;
	for (int nFacet = 0; nFacet < 12; nFacet++)//��ѭ�� ����12����
	{
		for (int nPoint = 0; nPoint < 5; nPoint++)//����ѭ�� ��5��������������
		{
			ScreenPoint.x = P[F[nFacet].Index[nPoint]].x;
			ScreenPoint.y = P[F[nFacet].Index[nPoint]].y;
			if (0 == nPoint)
			{
				pDC->MoveTo(ROUND(ScreenPoint.x), ROUND(ScreenPoint.y));
				temp = ScreenPoint;
			}
			else
			{
				pDC->LineTo(ROUND(ScreenPoint.x), ROUND(ScreenPoint.y));
			}
		}
		pDC->LineTo(ROUND(temp.x), ROUND(temp.y));//�պ��ı���
	}
}
