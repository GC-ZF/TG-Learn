#pragma once
#include "P3.h"
#include "Facet.h"

class COBJ
{
public:
	COBJ(void);
	virtual ~COBJ(void);
public:
	void ReadOBJFile(CString filePath);
	void Draw(CDC* pDC);
public:
	vector<CP3> vertex;
	vector<CFacet> facet;
};

