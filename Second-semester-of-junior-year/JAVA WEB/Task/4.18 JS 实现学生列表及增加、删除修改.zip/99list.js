// 获取新增按钮，点击显示表单
document.getElementById('add-btn').onclick = function() {
	document.getElementsByClassName('modal-div')[0].style.display = "inline";
}
// 获取x按钮，点击关闭表单
document.getElementById('close-modal-btn').onclick = function() {
	document.getElementsByClassName('modal-div')[0].style.display = "none";
}
// 给新增按钮添加监听
document.getElementById("add-btn").addEventListener("click", newadd);

function newadd() {
	document.getElementById('submit-button').onclick = function() {
		checkForm()
	}
}
// 修改按钮添加监听
document.getElementById("modify-btn").addEventListener("click", modify);

function modify() {
	document.getElementById('submit-button').onclick = function() {
		update()
	}
}

function checkForm() {
	// 创建add
	var mylist = document.getElementById('msgList-ul')
	var lis = document.createElement("li")
	lis.setAttribute("class", "female")
	var d = document.createElement("div")
	d.setAttribute("class", "img-div")

	var e = document.createElement("img")
	e.setAttribute("class", "img")
	e.setAttribute("src", "../img/9901.png")

	var w = document.createElement("div")
	w.setAttribute("class", "msg-span-div")

	document.getElementsByClassName('modal-div')[0].style.display = "none";
	mylist.appendChild(lis).appendChild(d).appendChild(e)

	mylist.appendChild(lis).appendChild(w)

	var t = document.createElement("span")
	t.setAttribute("class", "num-span")
	t.innerHTML = document.getElementsByTagName('input')[1].value
	mylist.appendChild(lis).appendChild(w).appendChild(t)

	var y = document.createElement("span")
	mylist.appendChild(lis).appendChild(w).appendChild(y)

	var u = document.createElement("span")
	u.setAttribute("class", "name-span")
	u.innerHTML = document.getElementsByTagName('input')[2].value
	mylist.appendChild(lis).appendChild(w).appendChild(y).appendChild(u)

	var i = document.createElement("span")
	i.setAttribute("class", "sex-span")
	// 性别判断
	let radioArr = document.getElementsByName("sex");
	let value;
	for (let index in radioArr) {
		if (radioArr[index].checked) {
			value = index;
			break;
		}
	}
	const descArr = ["男", "女"];
	console.log("选中：" + value + " ," + descArr[value]);
	if(value!=1){
		lis.setAttribute("class", "male")
	}
	i.innerHTML = descArr[value]


	mylist.appendChild(lis).appendChild(w).appendChild(y).appendChild(i)

	var o = document.createElement("span")
	o.setAttribute("class", "depart-span")

	var myselect = document.getElementById("department")
	var index = myselect.selectedIndex
	console.log(index)

	var oper_value = myselect.options[index].value
	console.log(oper_value)

	var oper_text = myselect.options[index].text

	o.innerHTML = oper_text
	mylist.appendChild(lis).appendChild(w).appendChild(o)

	var p = document.createElement("span")
	p.setAttribute("class", "like-span")
	mylist.appendChild(lis).appendChild(w).appendChild(p)


	var obj = document.getElementsByName("like");
	var baseTable = [];
	for (var i in obj) {
		if (obj[i].checked) {
			var n = document.createElement("span")
			if (obj[i].value == 'music') {
				n.innerHTML = '音乐'
			} else if (obj[i].value == 'sport') {
				n.innerHTML = '运动'
			} else if (obj[i].value == 'read') {
				n.innerHTML = '读书'
			} else if (obj[i].value == 'study') {
				n.innerHTML = '学习'
			}
			mylist.appendChild(lis).appendChild(w).appendChild(p).appendChild(n)
		}
	}
	var msglistUI = document.getElementById("msgList-ul")
	var liList = msglistUI.childNodes
	liList.forEach(function(item, index) {
		item.onclick = function() {
			clickItem(this)
		}
	})
}

function update() {
	var li = document.getElementsByClassName('active-li')
	var msgForm = document.msgForm
	var numSpan = li[0].getElementsByClassName('num-span')[0]
	numSpan.innerHTML = msgForm['number'].value

	var nameSpan = li[0].getElementsByClassName('name-span')[0]
	nameSpan.innerHTML = msgForm['name'].value

	var sexSpan = li[0].getElementsByClassName('sex-span')[0]
	sexSpan.innerHTML = msgForm['sex'].value == 'male' ? '男' : '女'
	console.log(sexSpan.innerHTML)

	var departSpan = li[0].getElementsByClassName('depart-span')[0]
	departSpan.innerHTML = msgForm['department'].value

	var likeSpan = li[0].getElementsByClassName('like-span')[0]
	msgForm['like'].forEach(function(item, index) {
		if (likeSpan.innerHTML.indexOf(item.nextElementSibling.innerHTML) > -1) {
			item.checked = 'checked'
		}
	})
	document.getElementsByClassName('modal-div')[0].style.display = "none";
}

function clickItem(ele) {
	if (ele.className.indexOf('active-li') > -1) {
		ele.className = ele.className.replace(' active-li', '')
	} else {
		var activeItems = document.getElementsByClassName(' active-li')
		if (activeItems.length > 0) {
			for (var i = 0; activeItems.length; i++) {
				activeItems[i].className = activeItems[i].className.replace(' active-li', '')
			}
		}
		ele.className = ele.className + ' active-li'
	}
}

function showModal(type) {
	if (type == 'modify') {
		var li = document.getElementsByClassName('active-li')
		if (li.length < 1) {
			alert('请选择要修改的学生')
			return
		}
		setFormByLi(li[0])
	}
	var modalDiv = document.getElementById('form-div')
	modalDiv.style.display = 'flex'

	var title = modalDiv.getElementsByClassName('form-title')[0]
	if (type == 'add') {
		title.innerHTML = '新增'

	} else {
		title.innerHTML = '修改'
	}
}

window.onload = function() {
	var msglistUI = document.getElementById("msgList-ul")
	var liList = msglistUI.childNodes
	liList.forEach(function(item, index) {
		item.onclick = function() {
			clickItem(this)
		}
	})

	var delBtn = document.getElementById("del-btn")
	delBtn.onclick = function() {
		deleteMsg()
	}
}

function deleteMsg() {
	var li = document.getElementsByClassName('active-li')[0].remove()
}

var modifyBtn = document.getElementById('modify-btn')
modifyBtn.onclick = function() {
	var li = document.getElementsByClassName('active-li')
	if (li.length < 1) {
		alert('请选择一个人')
		return
	} else {
		var li = document.getElementsByClassName('active-li')
		var msgForm = document.msgForm

		var numSpan = li[0].getElementsByClassName('num-span')[0]
		msgForm['number'].value = numSpan.innerHTML

		var nameSpan = li[0].getElementsByClassName('name-span')[0]
		msgForm['name'].value = nameSpan.innerHTML

		var sexSpan = li[0].getElementsByClassName('sex-span')[0]
		msgForm['sex'].value == sexSpan.innerHTML
		console.log(sexSpan.innerHTML)

		var departSpan = li[0].getElementsByClassName('depart-span')[0]
		msgForm['department'].value = departSpan.innerHTML

		var likeSpan = li[0].getElementsByClassName('like-span')[0]
		msgForm['like'].forEach(function(item, index) {
			if (likeSpan.innerHTML.indexOf(item.nextElementSibling.innerHTML) > -1) {
				item.checked = 'checked'
			}
		})
		document.getElementsByClassName('modal-div')[0].style.display = "inline";
	}
}