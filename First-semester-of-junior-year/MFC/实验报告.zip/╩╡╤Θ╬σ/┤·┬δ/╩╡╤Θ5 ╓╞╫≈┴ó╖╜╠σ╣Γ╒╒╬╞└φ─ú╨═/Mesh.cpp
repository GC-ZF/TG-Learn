#include "pch.h"
#include "Mesh.h"
#define ROUND(d) int(d + 0.5)

CMesh::CMesh(void)
{
}

CMesh:: ~CMesh(void)
{
}
