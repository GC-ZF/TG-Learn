#include "pch.h"
#include "Cube.h"
#define ROUND(d) int(d + 0.5)

CCube::CCube(void)
{

}

CCube::~CCube(void)
{

}

CP3* CCube::GetVertexArrayName(void)
{
	return	P;
}

void CCube::ReadPoint(void)//���
{
	//�������ά����(x,y,z)
	P[0] = CP3(0, 0, 0);
	P[1] = CP3(1, 0, 0);
	P[2] = CP3(1, 0, 1);
	P[3] = CP3(0, 0, 1);
	P[4] = CP3(0.5, 1, 0.5);
}

void CCube::ReadFacet(void)//���
{
	//��Ķ������
	F[0].Index[0] = 0; F[0].Index[1] = 4; F[0].Index[2] = 1; F[0].Index[3] = 1;
	F[1].Index[0] = 1; F[1].Index[1] = 4; F[1].Index[2] = 2; F[1].Index[3] = 2;
	F[2].Index[0] = 2; F[2].Index[1] = 4; F[2].Index[2] = 3; F[2].Index[3] = 3;
	F[3].Index[0] = 0; F[3].Index[1] = 3; F[3].Index[2] = 4; F[3].Index[3] = 4;
	F[4].Index[0] = 0; F[4].Index[1] = 1; F[4].Index[2] = 2; F[4].Index[3] = 3;
	 
}

void CCube::Draw(CDC* pDC)//����ͶӰ
{
	CP2 ScreenPoint, temp;
	for (int nFacet = 0; nFacet < 5; nFacet++)
	{
		for (int nPoint = 0; nPoint < 4; nPoint++)
		{
			ScreenPoint = P[F[nFacet].Index[nPoint]];
			if (0 == nPoint)
			{
				pDC->MoveTo(ROUND(ScreenPoint.x), ROUND(ScreenPoint.y));
				temp = ScreenPoint;
			}
			else
			{
				pDC->LineTo(ROUND(ScreenPoint.x), ROUND(ScreenPoint.y));
			}
		}
		pDC->LineTo(ROUND(temp.x), ROUND(temp.y));
	}

}
